import speech_recognition as sr
import pyttsx3
import os
import time
from gesture import set_device, append_log

VOICE_RATE = 170
VOICE_VOLUME = 1.0
tts = pyttsx3.init()
tts.setProperty("rate", VOICE_RATE)
tts.setProperty("volume", VOICE_VOLUME)

is_listening = False

def speak(text: str):
    print("TTS:", text)
    tts.say(text)
    tts.runAndWait()

def parse_command(text: str):
    c = text.lower().strip()
    if any(p in c for p in ["light on", "turn on light", "switch on light"]):
        set_device("Light", True, "Voice"); return
    if any(p in c for p in ["light off", "turn off light", "switch off light"]):
        set_device("Light", False, "Voice"); return
    if any(p in c for p in ["fan on", "turn on fan", "switch on fan"]):
        set_device("Fan", True, "Voice"); return
    if any(p in c for p in ["fan off", "turn off fan", "switch off fan"]):
        set_device("Fan", False, "Voice"); return
    if any(p in c for p in ["tv on", "turn on tv", "switch on tv"]):
        set_device("TV", True, "Voice"); return
    if any(p in c for p in ["tv off", "turn off tv", "switch off tv"]):
        set_device("TV", False, "Voice"); return
    if any(p in c for p in ["exit", "quit", "close app"]):
        speak("Shutting down. Goodbye!")
        os._exit(0)
    append_log(f"Unknown command: {text}")
    speak("Command not recognized.")

def voice_loop(listen_btn):
    global is_listening
    r = sr.Recognizer()
    mic = sr.Microphone()
    is_listening = True
    listen_btn.config(text="Stop Listening")
    append_log("Microphone listening started...")
    while is_listening:
        try:
            with mic as src:
                r.adjust_for_ambient_noise(src)
                audio = r.listen(src, timeout=6, phrase_time_limit=5)
            cmd = r.recognize_google(audio)
            append_log(f"You said: {cmd}")
            parse_command(cmd)
        except sr.UnknownValueError:
            continue
        except Exception as e:
            append_log(f"Voice error: {e}")
            time.sleep(0.2)

def stop_listening(listen_btn):
    global is_listening
    is_listening = False
    listen_btn.config(text="Start Listening")
    append_log("Microphone listening stopped.")
