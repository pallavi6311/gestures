from ui import build_gui
from camera import camera_loop
from voice import voice_loop, stop_listening
import threading

def toggle_listening(listen_btn):
    if listen_btn['text'] == "Start Listening":
        threading.Thread(target=voice_loop, args=(listen_btn,), daemon=True).start()
    else:
        stop_listening(listen_btn)

if __name__ == "__main__":
    root = build_gui(lambda: toggle_listening(root.nametowidget('!button')), camera_loop)
    root.mainloop()
