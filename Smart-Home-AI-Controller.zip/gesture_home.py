
# Refactored imports
import speech_recognition as sr
import pyttsx3
import threading
import os
import time
from ui import build_gui
from gesture import devices, device_labels, set_device, append_log
from camera import camera_loop

VOICE_RATE = 170
VOICE_VOLUME = 1.0
is_listening = False
tts = pyttsx3.init()
tts.setProperty("rate", VOICE_RATE)
tts.setProperty("volume", VOICE_VOLUME)

def speak(text: str):
    print("TTS:", text)
    tts.say(text)
    tts.runAndWait()

"""
    with open("actions.log", "a", encoding="utf-8") as f:
