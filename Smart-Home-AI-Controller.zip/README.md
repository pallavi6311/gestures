# Smart Home AI Controller

A Python-based AI system that controls smart home devices (Light, Fan, TV) using:
- 🎤 Voice Commands (SpeechRecognition + pyttsx3)
- ✋ Hand Gestures (MediaPipe + OpenCV)
- 🧠 Presence Detection (Face Detection + Auto-Off)
- 🖥️ Streamlit & Tkinter Interfaces

## 🚀 Run the Project

### Tkinter Version
```bash
python main.py
```

### Streamlit Version
```bash
streamlit run streamlit_app.py
```

## 🧩 Requirements
Install dependencies:
```bash
pip install opencv-python mediapipe streamlit pyttsx3 SpeechRecognition Pillow
```

## 📝 Features
- Real-time camera gesture recognition
- Voice-based home automation
- Auto-off when no face detected
- Clean, modular design

---
© 2025 Smart Home AI Controller by Pallavi
