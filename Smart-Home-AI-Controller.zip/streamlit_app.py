import streamlit as st
import cv2
import numpy as np
from PIL import Image

def recognize_gesture(frame):
    # TODO: Replace with actual gesture recognition logic
    return "None"

def main():
    st.set_page_config(page_title="Smart Home AI Controller", layout="wide")
    st.title("Smart Home AI Panel")
    st.markdown("---")
    st.sidebar.header("Devices")
    devices = ["Light", "Fan", "TV", "AC"]
    device_states = {}
    for dev in devices:
        device_states[dev] = st.sidebar.toggle(f"{dev}")
    st.sidebar.markdown("---")
    st.sidebar.write("Use voice, gestures, and presence detection.")

    st.subheader("Camera Feed & Gesture Recognition")
    run_camera = st.checkbox("Show Camera Feed")
    gesture_placeholder = st.empty()
    camera_placeholder = st.empty()
    gesture_history = st.empty()
    history = st.session_state.get("gesture_history", [])

    import time
    if run_camera:
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            st.error("Camera not available.")
        else:
            stop = False
            stop_btn = st.button("Stop Camera", key="stop_camera_btn")
            while run_camera and not stop:
                ret, frame = cap.read()
                if not ret:
                    st.error("Failed to read from camera.")
                    break
                gesture_result = recognize_gesture(frame)
                gesture_placeholder.markdown(f"**Gesture:** {gesture_result}")
                history.append(gesture_result)
                if len(history) > 10:
                    history = history[-10:]
                gesture_history.markdown("**Recent Gestures:** " + ", ".join(history))
                # Add hand marker (circle at center as placeholder)
                h, w, _ = frame.shape
                center_x, center_y = w // 2, h // 2
                cv2.circle(frame, (center_x, center_y), 40, (0, 255, 0), 3)
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(rgb)
                camera_placeholder.image(img, caption="Live Camera", use_container_width=True)
                time.sleep(0.05)
                # Check if stop button pressed
                if stop_btn:
                    stop = True
                    break
            cap.release()
        st.session_state["gesture_history"] = history

    st.subheader("Command Log")
    st.text_area("Log", value="✅ System ready. Use voice, gestures, and presence detection.", height=200)

if __name__ == "__main__":
    main()
