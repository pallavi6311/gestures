import cv2
import datetime
from gesture import face_cascade, last_face_seen, set_device, devices, count_fingers, apply_gesture_action, mp_draw, hands, mp_hands, append_log
AUTO_OFF_SECONDS = 10

def set_all_off(method="Auto-Off"):
    turned_any = False
    for dev, state in list(devices.items()):
        if state:
            set_device(dev, False, method)
            turned_any = True
    if turned_any and method == "Auto-Off":
        append_log("⚠️ No one detected. Everything turned OFF.")

def camera_loop():
    global last_face_seen
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        append_log("Camera not available.")
        return

    while True:
        ok, frame = cap.read()
        if not ok:
            continue

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        if len(faces) > 0:
            last_face_seen = datetime.datetime.now()
        else:
            if (datetime.datetime.now() - last_face_seen).total_seconds() > AUTO_OFF_SECONDS:
                set_all_off("Auto-Off")

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = hands.process(rgb)
        if result.multi_hand_landmarks:
            for hand_lms in result.multi_hand_landmarks:
                mp_draw.draw_landmarks(frame, hand_lms, mp_hands.HAND_CONNECTIONS)
                try:
                    cnt = count_fingers(hand_lms.landmark)
                    apply_gesture_action(cnt)
                    cv2.putText(frame, f"Fingers: {cnt}", (10, 30),
                                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                except Exception:
                    pass

        cv2.imshow("AI Camera (press q to quit)", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
