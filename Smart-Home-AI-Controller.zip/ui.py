import tkinter as tk
from tkinter import scrolledtext
import threading
from gesture import set_device, devices, device_labels, append_log

def build_gui(toggle_listening, camera_loop):
    import cv2
    from PIL import Image, ImageTk
    global root, log_box, listen_btn, camera_label, gesture_label
    root = tk.Tk()
    root.title("Smart Home AI Controller")
    root.geometry("800x700")
    root.configure(bg="#1c1c1e")

    tk.Label(root, text="Smart Home AI Panel",
             font=("Helvetica", 20, "bold"), fg="white", bg="#1c1c1e").pack(pady=10)

    panel = tk.Frame(root, bg="#1c1c1e")
    panel.pack(pady=6)

    for dev in devices:
        lbl = tk.Label(panel, text=f"{dev}: OFF", font=("Arial", 18),
                       fg="red", bg="#1c1c1e")
        lbl.pack(pady=4)
        device_labels[dev] = lbl

    listen_btn = tk.Button(root, text="Start Listening",
                           font=("Arial", 14), command=toggle_listening)
    listen_btn.pack(pady=10)

    # Camera view
    camera_label = tk.Label(root, bg="#1c1c1e")
    camera_label.pack(pady=10)

    # Gesture result
    gesture_label = tk.Label(root, text="Gesture: None", font=("Arial", 16), fg="yellow", bg="#1c1c1e")
    gesture_label.pack(pady=4)

    tk.Label(root, text="Command Log:", fg="white", bg="#1c1c1e").pack()
    log_box = scrolledtext.ScrolledText(root, height=12, state="disabled",
                                        bg="#2e2e2e", fg="white", wrap="word")
    log_box.pack(fill="both", expand=True, padx=10, pady=8)

    append_log("✅ System ready. Use voice, gestures, and presence detection.")

    # Camera loop for live feed and gesture recognition
    def camera_feed():
        cap = cv2.VideoCapture(0)
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            # Gesture recognition placeholder
            gesture_result = recognize_gesture(frame)  # You must implement this function
            # Show gesture result
            gesture_label.config(text=f"Gesture: {gesture_result}")
            # Convert frame to Tkinter image
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(rgb)
            imgtk = ImageTk.PhotoImage(image=img.resize((480, 360)))
            camera_label.imgtk = imgtk
            camera_label.config(image=imgtk)
            root.update_idletasks()
            root.update()
        cap.release()

    # Start camera feed in a thread
    threading.Thread(target=camera_feed, daemon=True).start()
    return root

# Dummy gesture recognition function
def recognize_gesture(frame):
    # TODO: Replace with actual gesture recognition logic
    return "None"
