import datetime
import mediapipe as mp
import cv2
import threading

devices = {"Light": False, "Fan": False, "TV": False}
device_labels = {}

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
mp_draw = mp.solutions.drawing_utils

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

last_face_seen = datetime.datetime.now()

try:
    from ui import append_log as ui_append_log
    def append_log(msg):
        ui_append_log(msg)
except ImportError:
    append_log = lambda msg: print(msg)

def set_device(device, state, method="System"):
    devices[device] = state
    lbl = device_labels.get(device)
    if lbl:
        lbl.config(text=f"{device}: {'ON' if state else 'OFF'}",
                   fg="green" if state else "red")
    ts = datetime.datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {method}: {device} → {'ON' if state else 'OFF'}"
    append_log(line)

def count_fingers(landmarks):
    fingers = []
    fingers.append(1 if landmarks[4].x < landmarks[3].x else 0)
    for tip in [8, 12, 16, 20]:
        fingers.append(1 if landmarks[tip].y < landmarks[tip - 2].y else 0)
    return sum(fingers)

def apply_gesture_action(count):
    if count == 0 and devices["Light"]:
        set_device("Light", False, "Gesture")
    elif count == 1 and not devices["Light"]:
        set_device("Light", True, "Gesture")
    elif count == 2:
        set_device("Fan", not devices["Fan"], "Gesture")
    elif count == 3 and devices["Fan"]:
        set_device("Fan", False, "Gesture")
    elif count == 4 and not devices["TV"]:
        set_device("TV", True, "Gesture")
    elif count == 5 and devices["TV"]:
        set_device("TV", False, "Gesture")
